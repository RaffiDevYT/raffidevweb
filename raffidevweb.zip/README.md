## :memo: License

This project is under license from MIT. For more details, see the [LICENSE](LICENSE.md) file.

Made with :heart: by <a href="https://github.com/RaffiDevYT" target="_blank">Rafi Athallah</a>

&#xa0;

<a href="#top">Back to top</a>
